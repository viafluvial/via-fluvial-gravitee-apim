#!/usr/bin/env bash
set -euo pipefail

if command -v ansible-playbook >/dev/null 2>&1; then
  echo "ansible ja instalado: $(command -v ansible-playbook)"
  ansible --version | head -n 1 || true
  exit 0
fi

install_via_apt() {
  if [[ "$(id -u)" -eq 0 ]]; then
    apt-get update -y
    apt-get install -y ansible
    return 0
  fi

  if command -v sudo >/dev/null 2>&1; then
    if sudo -n true >/dev/null 2>&1; then
      sudo apt-get update -y
      sudo apt-get install -y ansible
      return 0
    fi

    echo "Solicitando senha sudo para instalar ansible..."
    if sudo -v; then
      sudo apt-get update -y
      sudo apt-get install -y ansible
      return 0
    fi
  fi

  return 1
}

install_via_pip_user() {
  if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 nao encontrado para instalar ansible via pip --user" >&2
    return 1
  fi

  python3 -m ensurepip --upgrade >/dev/null 2>&1 || true
  python3 -m pip install --user --upgrade pip
  python3 -m pip install --user --upgrade ansible-core
}

if ! install_via_apt; then
  echo "Sem privilegio root/sudo; instalando ansible-core no usuario (~/.local/bin)" >&2
  install_via_pip_user
fi

export PATH="${HOME}/.local/bin:$PATH"
if ! command -v ansible-playbook >/dev/null 2>&1; then
  echo "Falha ao instalar ansible (ansible-playbook indisponivel)." >&2
  exit 1
fi

echo "ansible instalado: $(command -v ansible-playbook)"
ansible --version | head -n 1 || true
