#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[bootstrap] Iniciando preparação local (make + ansible)..."

bash "$SCRIPT_DIR/install-make.sh"
bash "$SCRIPT_DIR/install-sshpass.sh"
bash "$SCRIPT_DIR/install-ansible.sh"

if ! command -v make >/dev/null 2>&1; then
  echo "[bootstrap] Falha: make não disponível após instalação." >&2
  exit 1
fi

if ! command -v ansible-playbook >/dev/null 2>&1; then
  echo "[bootstrap] Falha: ansible-playbook não disponível após instalação." >&2
  exit 1
fi

if ! command -v sshpass >/dev/null 2>&1; then
  echo "[bootstrap] Falha: sshpass não disponível após instalação." >&2
  exit 1
fi

echo "[bootstrap] Ambiente local pronto."
echo "[bootstrap] make: $(command -v make)"
echo "[bootstrap] sshpass: $(command -v sshpass)"
echo "[bootstrap] ansible-playbook: $(command -v ansible-playbook)"
