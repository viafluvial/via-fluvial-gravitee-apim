#!/usr/bin/env bash
set -euo pipefail

if command -v make >/dev/null 2>&1; then
  echo "make ja instalado: $(command -v make)"
  make --version | head -n 1 || true
  exit 0
fi

install_via_apt() {
  if [[ "$(id -u)" -eq 0 ]]; then
    apt-get update -y
    apt-get install -y make
    return 0
  fi

  if command -v sudo >/dev/null 2>&1; then
    if sudo -n true >/dev/null 2>&1; then
      sudo apt-get update -y
      sudo apt-get install -y make
      return 0
    fi

    echo "Solicitando senha sudo para instalar make..."
    if sudo -v; then
      sudo apt-get update -y
      sudo apt-get install -y make
      return 0
    fi
  fi

  return 1
}

if ! install_via_apt; then
  echo "Falha ao instalar make: privilegio root/sudo indisponivel para apt." >&2
  echo "Instale manualmente o pacote 'make' e execute novamente." >&2
  exit 1
fi

if ! command -v make >/dev/null 2>&1; then
  echo "Falha ao instalar make (comando indisponivel apos instalacao)." >&2
  exit 1
fi

echo "make instalado: $(command -v make)"
make --version | head -n 1 || true
