#!/usr/bin/env bash
set -euo pipefail

ACTION="${1:-install}"
ENVIRONMENT="${2:-prd}"
TARGET="${3:-}"
WITH_PREREQS="${4:-false}"
INVENTORY_LIMIT="${INVENTORY_LIMIT:-}"
SERVER_IP_OVERRIDE="${SERVER_IP_OVERRIDE:-}"
INVENTORY_FILE_OVERRIDE="${INVENTORY_FILE_OVERRIDE:-}"
ALLOW_DSV_CHANGES="${ALLOW_DSV_CHANGES:-false}"
TASK_HISTORY_LIMIT="${TASK_HISTORY_LIMIT:-1}"
CLEAN_STACKS="${CLEAN_STACKS:-traefik,portainer}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ANSIBLE_DIR="$ROOT_DIR/ansible"
PLAYBOOKS_DIR="$ANSIBLE_DIR/playbooks"
INVENTORY_FILE="$ANSIBLE_DIR/config/inventory.ini"

INVENTORY_GROUP=""
SERVER_IP=""
EFFECTIVE_CLUSTER=""
PRD_GROUPS=(identity management repository application gateway api)

usage() {
	cat <<USAGE
Uso:
	scripts/iac.sh <install|uninstall|check|clean|clean-hard> [dsv|hml|prd] [target] [true|false]

Exemplos:
	scripts/iac.sh install prd identity true
	scripts/iac.sh check prd identity
	scripts/iac.sh check dsv identity
	scripts/iac.sh clean prd identity
	scripts/iac.sh clean-hard prd identity

Variaveis opcionais:
	INVENTORY_LIMIT=<grupo_ou_host>
	INVENTORY_FILE_OVERRIDE=<arquivo_inventory.ini>
	SERVER_IP_OVERRIDE=<ip>
	ALLOW_DSV_CHANGES=true (exige confirmacao explicita para install/uninstall em dsv)
	TASK_HISTORY_LIMIT=<n> (default: 1)
	CLEAN_STACKS=<lista separada por virgula> (default: traefik,portainer)
USAGE
}

require_tools() {
	command -v ansible-playbook >/dev/null 2>&1 || {
		echo "ansible-playbook nao encontrado. Execute: make setup-local" >&2
		exit 1
	}
}

resolve_server_ip_from_inventory() {
	local limit_target="$1"
	local target_line=""

	if grep -q "^\[$limit_target\]" "$INVENTORY_FILE"; then
		target_line="$({
			awk -v group="$limit_target" '
				$0 ~ "^\\[" group "\\]" { in_group=1; next }
				in_group && $0 ~ /^\[/ { exit }
				in_group && $0 !~ /^[[:space:]]*$/ && $0 !~ /^[[:space:]]*#/ { print; exit }
			' "$INVENTORY_FILE"
		})"
	else
		target_line="$({
			awk -v host="$limit_target" '$1 == host { print; exit }' "$INVENTORY_FILE"
		})"
	fi

	if [[ -z "$target_line" ]]; then
		return 0
	fi

	echo "$target_line" | sed -nE 's/.*ansible_host=([^ ]+).*/\1/p'
}

resolve_target() {
	local normalized_target="${TARGET,,}"

	case "$ENVIRONMENT" in
		dsv)
			INVENTORY_FILE="$ANSIBLE_DIR/config/inventory.ini"
			INVENTORY_GROUP="${TARGET:-dsv}"
			EFFECTIVE_CLUSTER="${TARGET:-dsv}"
			;;
		hml)
			INVENTORY_FILE="$ANSIBLE_DIR/config/inventory.ini"
			INVENTORY_GROUP="${TARGET:-hml}"
			EFFECTIVE_CLUSTER="${TARGET:-hml}"
			;;
		prd)
			INVENTORY_FILE="$ANSIBLE_DIR/config/inventory/prd.ini"
			if [[ -z "$TARGET" || "$normalized_target" == "all" ]]; then
				INVENTORY_GROUP="all"
				EFFECTIVE_CLUSTER="all"
			elif [[ " ${PRD_GROUPS[*]} " =~ " ${normalized_target} " ]]; then
				INVENTORY_GROUP="$normalized_target"
				EFFECTIVE_CLUSTER="$normalized_target"
			else
				echo "[iac] TARGET invalido para prd: '$TARGET'. Use all, identity, management, repository, application, gateway ou api." >&2
				exit 1
			fi
			;;
		*)
			echo "Ambiente '$ENVIRONMENT' nao suportado. Use dsv, hml ou prd." >&2
			exit 1
			;;
	esac

	if [[ -n "$INVENTORY_FILE_OVERRIDE" ]]; then
		INVENTORY_FILE="$INVENTORY_FILE_OVERRIDE"
	fi

	if [[ ! -f "$INVENTORY_FILE" ]]; then
		echo "Arquivo de inventario nao encontrado: $INVENTORY_FILE" >&2
		exit 1
	fi

	if [[ -n "$INVENTORY_LIMIT" ]]; then
		INVENTORY_GROUP="$INVENTORY_LIMIT"
		EFFECTIVE_CLUSTER="$INVENTORY_LIMIT"
	fi

	if [[ -n "$SERVER_IP_OVERRIDE" ]]; then
		SERVER_IP="$SERVER_IP_OVERRIDE"
	else
		SERVER_IP="$(resolve_server_ip_from_inventory "$INVENTORY_GROUP")"
	fi

	echo "[iac] Ambiente: $ENVIRONMENT"
	echo "[iac] Target recebido: $TARGET"
	echo "[iac] Cluster efetivo: $EFFECTIVE_CLUSTER"
	echo "[iac] Inventory file: $INVENTORY_FILE"
	echo "[iac] Limit/Grupo: $INVENTORY_GROUP"
	if [[ -n "$SERVER_IP" ]]; then
		echo "[iac] SERVER_IP detectado: $SERVER_IP"
	else
		echo "[iac] SERVER_IP nao detectado no inventario para '$INVENTORY_GROUP' (seguindo sem bloqueio)."
	fi
}

run_action_for_group() {
	local group="$1"
	INVENTORY_GROUP="$group"
	EFFECTIVE_CLUSTER="$group"

	if [[ -n "$SERVER_IP_OVERRIDE" ]]; then
		SERVER_IP="$SERVER_IP_OVERRIDE"
	else
		SERVER_IP="$(resolve_server_ip_from_inventory "$INVENTORY_GROUP")"
	fi

	echo "[iac] ---- Executando acao '$ACTION' no grupo '$group' ----"
	if [[ -n "$SERVER_IP" ]]; then
		echo "[iac] SERVER_IP detectado para '$group': $SERVER_IP"
	else
		echo "[iac] SERVER_IP nao detectado para '$group' (seguindo sem bloqueio)."
	fi

	prepare_env_files

	case "$ACTION" in
		install)
			run_install
			;;
		uninstall)
			run_uninstall
			;;
		check)
			run_check
			;;
		clean)
			run_clean
			;;
		clean-hard)
			run_clean_hard
			;;
		*)
			usage
			exit 1
			;;
	esac
}

prepare_env_files() {
	cat > "$PLAYBOOKS_DIR/.env.traefik" <<EOT
TRAEFIK_EMAIL=ti@tjam.jus.br
TRAEFIK_APPLICATION=traefik
TRAEFIK_CLUSTER=${EFFECTIVE_CLUSTER}
TRAEFIK_DOMAIN=tjam.jus.br
TRAEFIK_USERNAME=tjam@
TRAEFIK_PASSWORD=Pl43f0rM3j4M@
TRAEFIK_PASSWORD_HASHED='\$apr1\$LpCOGBTC\$RNkuAY24XlAzGfqzLwIVG/'
EOT

	cat > "$PLAYBOOKS_DIR/.env.portainer" <<EOT
PORTAINER_APPLICATION=portainer
PORTAINER_CLUSTER=${EFFECTIVE_CLUSTER}
PORTAINER_DOMAIN=tjam.jus.br
PORTAINER_USERNAME=tjam@
PORTAINER_PASSWORD=Pl43f0rM3j4M@
PORTAINER_LICENSE=3-AHEcdVKUg45BU+78pT/kkhdvfXb90HhgaWI/Czx4+vpULUvIRDGwIjaOTx64EZ/zZFAQbijFy4VHSwMffIJT4m05lIq7TcN616PKnQklkTz35HKK43cFe1UNGYcFY91dvrc=
SERVER_IP=${SERVER_IP}
EOT
}

run_playbook() {
	local playbook="$1"
	ANSIBLE_CONFIG="$ANSIBLE_DIR/config/ansible.cfg" ansible-playbook \
		-i "$INVENTORY_FILE" \
		"$PLAYBOOKS_DIR/$playbook" \
		-e "project_root=$ROOT_DIR" \
		--limit "$INVENTORY_GROUP"
}

run_install() {
	run_playbook playbook-01C-init.yml
	run_playbook playbook-02C-install-docker-vm.yml
	run_playbook playbook-03C-install-docker-swarm-vm.yml
	run_playbook playbook-04C-install-docker-swarm-network-vm.yml
	run_playbook playbook-05C-install-traefik-vm.yml
	run_playbook playbook-06C-install-portainer-vm.yml
}

run_uninstall() {
	run_playbook playbook-06D-uninstall-portainer-vm.yml
	run_playbook playbook-05D-uninstall-traefik-vm.yml
	run_playbook playbook-04D-uninstall-docker-swarm-network-vm.yml
	run_playbook playbook-03D-uninstall-docker-swarm-vm.yml
	run_playbook playbook-02D-uninstall-docker-vm.yml
	run_playbook playbook-01D-init.yml
}

run_check() {
	for pb in "$PLAYBOOKS_DIR"/playbook-*.yml; do
		ANSIBLE_CONFIG="$ANSIBLE_DIR/config/ansible.cfg" ansible-playbook \
			--syntax-check \
			-i "$INVENTORY_FILE" \
			"$pb" \
			-e "project_root=$ROOT_DIR" \
			--limit "$INVENTORY_GROUP"
	done
}

run_clean() {
	if ! [[ "$TASK_HISTORY_LIMIT" =~ ^[0-9]+$ ]]; then
		echo "TASK_HISTORY_LIMIT deve ser numerico. Valor atual: $TASK_HISTORY_LIMIT" >&2
		exit 1
	fi

	local stacks_regex
	stacks_regex="$(echo "$CLEAN_STACKS" | tr ',' '|' | tr -d ' ')"

	ANSIBLE_CONFIG="$ANSIBLE_DIR/config/ansible.cfg" ansible \
		-i "$INVENTORY_FILE" \
		"$INVENTORY_GROUP" \
		-b \
		-m shell \
		-a "set -eu
docker info 2>/dev/null | awk -F': ' '/Swarm:/{print \$2; exit}' | grep -q '^active$'
docker swarm update --task-history-limit $TASK_HISTORY_LIMIT >/dev/null
services=\$(docker service ls | awk 'NR>1 {print \$2}' | grep -E '^(${stacks_regex})_' || true)
if [ -z \"\$services\" ]; then
  echo 'Nenhum servico encontrado para stacks alvo.'
  exit 0
fi
echo \"\$services\" | while IFS= read -r svc; do
	[ -z \"\$svc\" ] && continue
  echo \"Forcando rollout de: \$svc\"
  docker service update --force \"\$svc\" >/dev/null
done
echo 'Limpeza de historico aplicada.'"
}

run_clean_hard() {
	run_playbook playbook-06D-uninstall-portainer-vm.yml
	run_playbook playbook-05D-uninstall-traefik-vm.yml
	run_playbook playbook-05C-install-traefik-vm.yml
	run_playbook playbook-06C-install-portainer-vm.yml
}

guard_environment_safety() {
	if [[ "$ENVIRONMENT" == "dsv" && ( "$ACTION" == "install" || "$ACTION" == "uninstall" || "$ACTION" == "clean" || "$ACTION" == "clean-hard" ) && "$ALLOW_DSV_CHANGES" != "true" ]]; then
		echo "[iac] Bloqueado por seguranca: alteracoes em dsv exigem ALLOW_DSV_CHANGES=true." >&2
		echo "[iac] Exemplo: ALLOW_DSV_CHANGES=true ENVIRONMENT=dsv make stacks $ACTION <target>" >&2
		exit 1
	fi
}

if [[ "$WITH_PREREQS" == "true" ]]; then
	"$ROOT_DIR/scripts/bootstrap-local.sh"
fi

require_tools
resolve_target
guard_environment_safety

if [[ "$ENVIRONMENT" == "prd" && "$INVENTORY_GROUP" == "all" && -z "$INVENTORY_LIMIT" ]]; then
	for group in "${PRD_GROUPS[@]}"; do
		run_action_for_group "$group"
	done
else
	prepare_env_files
	case "$ACTION" in
		install)
			run_install
			;;
		uninstall)
			run_uninstall
			;;
		check)
			run_check
			;;
		clean)
			run_clean
			;;
		clean-hard)
			run_clean_hard
			;;
		*)
			usage
			exit 1
			;;
	esac
fi
