#!/usr/bin/env bash
set -euo pipefail

if command -v sshpass >/dev/null 2>&1; then
  echo "sshpass ja instalado: $(command -v sshpass)"
  sshpass -V 2>&1 | head -n 1 || true
  exit 0
fi

install_via_apt() {
  if [[ "$(id -u)" -eq 0 ]]; then
    apt-get update -y
    apt-get install -y sshpass
    return 0
  fi

  if command -v sudo >/dev/null 2>&1; then
    if sudo -n true >/dev/null 2>&1; then
      sudo apt-get update -y
      sudo apt-get install -y sshpass
      return 0
    fi

    echo "Solicitando senha sudo para instalar sshpass..."
    if sudo -v; then
      sudo apt-get update -y
      sudo apt-get install -y sshpass
      return 0
    fi
  fi

  return 1
}

if ! install_via_apt; then
  echo "Falha ao instalar sshpass: privilegio root/sudo indisponivel para apt." >&2
  echo "Instale manualmente o pacote 'sshpass' e execute novamente." >&2
  exit 1
fi

if ! command -v sshpass >/dev/null 2>&1; then
  echo "Falha ao instalar sshpass (comando indisponivel apos instalacao)." >&2
  exit 1
fi

echo "sshpass instalado: $(command -v sshpass)"
sshpass -V 2>&1 | head -n 1 || true
