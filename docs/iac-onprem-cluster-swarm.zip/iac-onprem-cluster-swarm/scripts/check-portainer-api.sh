#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Uso: $0 <env-file> [stack_name ...]" >&2
  exit 1
fi

env_file="$1"
shift || true
stacks=("$@")

if [[ ! -f "$env_file" ]]; then
  echo "Arquivo env não encontrado: $env_file" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
. "$env_file"
set +a

: "${PORTAINER_URL:?PORTAINER_URL não definido em $env_file}"
: "${PORTAINER_ENDPOINT_ID:?PORTAINER_ENDPOINT_ID não definido em $env_file}"

if [[ -z "${PORTAINER_API_KEY:-}" && ( -z "${PORTAINER_USERNAME:-}" || -z "${PORTAINER_PASSWORD:-}" ) ]]; then
  echo "Defina PORTAINER_API_KEY ou PORTAINER_USERNAME/PORTAINER_PASSWORD em $env_file" >&2
  exit 1
fi

base_url="${PORTAINER_URL%/}"
validate_certs="${PORTAINER_VALIDATE_CERTS:-false}"
service_health_timeout="${PORTAINER_SERVICE_HEALTH_TIMEOUT:-600}"
service_health_interval="${PORTAINER_SERVICE_HEALTH_INTERVAL:-10}"

curl_opts=(--silent --show-error --fail)
if [[ "$validate_certs" == "false" ]]; then
  curl_opts+=(--insecure)
fi

api_headers=()

echo "[Portainer] Verificando conectividade: $base_url"
curl "${curl_opts[@]}" "$base_url/api/status" >/dev/null

if [[ -n "${PORTAINER_API_KEY:-}" ]]; then
  api_headers=(-H "X-API-Key: ${PORTAINER_API_KEY}")
else
  echo "[Portainer] Autenticando com usuário/senha"
  auth_response=$(curl "${curl_opts[@]}" \
    -H "Content-Type: application/json" \
    -X POST \
    -d "{\"username\":\"${PORTAINER_USERNAME}\",\"password\":\"${PORTAINER_PASSWORD}\"}" \
    "$base_url/api/auth")

  jwt=$(python3 - <<'PY' "$auth_response"
import json,sys
try:
    data=json.loads(sys.argv[1])
    print(data.get('jwt',''))
except Exception:
    print('')
PY
)

  if [[ -z "$jwt" ]]; then
    echo "Falha ao autenticar no Portainer (jwt vazio)." >&2
    exit 1
  fi

  api_headers=(-H "Authorization: Bearer $jwt")
fi

echo "[Portainer] Validando endpointId=$PORTAINER_ENDPOINT_ID"
curl "${curl_opts[@]}" "${api_headers[@]}" "$base_url/api/endpoints/$PORTAINER_ENDPOINT_ID" >/dev/null

stacks_response=$(curl "${curl_opts[@]}" "${api_headers[@]}" "$base_url/api/stacks?endpointId=$PORTAINER_ENDPOINT_ID")

if [[ ${#stacks[@]} -gt 0 ]]; then
  echo "[Portainer] Validando stacks no endpoint $PORTAINER_ENDPOINT_ID"
  python3 - <<'PY' "$stacks_response" "${stacks[@]}"
import json,sys
raw=sys.argv[1]
expected=set(sys.argv[2:])
try:
    data=json.loads(raw)
except Exception as exc:
    print(f'Falha ao parsear resposta de stacks: {exc}', file=sys.stderr)
    sys.exit(1)
found={item.get('Name') for item in data if isinstance(item, dict)}
missing=sorted(expected - found)
if missing:
    print('Stacks ausentes: ' + ', '.join(missing), file=sys.stderr)
    sys.exit(1)
print('Stacks validadas: ' + ', '.join(sorted(expected)))
PY

  echo "[Portainer] Validando saúde dos serviços (replicas running)"
  echo "[Portainer] Aguardando até ${service_health_timeout}s (intervalo ${service_health_interval}s) para estabilização"

  last_validation_output=""
  elapsed=0
  while true; do
    services_response=$(curl "${curl_opts[@]}" "${api_headers[@]}" "$base_url/api/endpoints/$PORTAINER_ENDPOINT_ID/docker/services?status=true")

    set +e
    validation_output=$(python3 - <<'PY' "$services_response" "${stacks[@]}"
import json,sys

raw=sys.argv[1]
expected_stacks=set(sys.argv[2:])

try:
  services=json.loads(raw)
except Exception as exc:
  print(f'Falha ao parsear resposta de serviços: {exc}', file=sys.stderr)
  sys.exit(1)

if not isinstance(services, list):
  print('Resposta de serviços inválida (esperada lista).', file=sys.stderr)
  sys.exit(1)

stack_services={stack: [] for stack in expected_stacks}

for svc in services:
  if not isinstance(svc, dict):
    continue
  labels=((svc.get('Spec') or {}).get('Labels') or {})
  stack_name=labels.get('com.docker.stack.namespace')
  if stack_name in stack_services:
    stack_services[stack_name].append(svc)

errors=[]
details=[]

for stack_name in sorted(expected_stacks):
  svcs=stack_services.get(stack_name, [])
  if not svcs:
    errors.append(f'Nenhum serviço encontrado para a stack {stack_name}')
    continue

  for svc in svcs:
    spec=svc.get('Spec') or {}
    mode=spec.get('Mode') or {}
    if 'Replicated' in mode:
      desired=int((mode.get('Replicated') or {}).get('Replicas') or 0)
    elif 'Global' in mode:
      # Para serviços globais, não há desired fixo aqui; tratamos como >=1 running.
      desired=1
    else:
      desired=1

    status=svc.get('ServiceStatus') or {}
    running=int(status.get('RunningTasks') or 0)
    name=spec.get('Name') or svc.get('ID') or 'unknown'

    details.append(f'{name}: {running}/{desired}')

    if desired > 0 and running < desired:
      errors.append(f'Serviço {name} não saudável: {running}/{desired} tasks running')

if errors:
  print('Falha na validação de saúde das stacks:')
  for err in errors:
    print(f' - {err}')
  if details:
    print('Resumo:')
    for item in details:
      print(f'   * {item}')
  sys.exit(1)

print('Serviços saudáveis:')
for item in details:
  print(f' - {item}')
PY
)
  validation_rc=$?
  set -e

  if [[ $validation_rc -eq 0 ]]; then
    echo "$validation_output"
    break
  fi

  last_validation_output="$validation_output"
  if (( elapsed >= service_health_timeout )); then
    echo "$last_validation_output" >&2
    exit 1
  fi

  sleep "$service_health_interval"
  elapsed=$((elapsed + service_health_interval))
  done
fi

echo "[Portainer] OK: conectividade/autenticação/endpoint válidos para $env_file"
