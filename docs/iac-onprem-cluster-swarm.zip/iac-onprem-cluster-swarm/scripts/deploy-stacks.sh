#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-all}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENVIRONMENT="${ENVIRONMENT:-prd}"
WITH_PREREQS="${WITH_PREREQS:-false}"

bash "$ROOT_DIR/scripts/iac.sh" install "$ENVIRONMENT" "$TARGET" "$WITH_PREREQS"

echo "Stacks instaladas com sucesso para ${TARGET} em ${ENVIRONMENT}."
