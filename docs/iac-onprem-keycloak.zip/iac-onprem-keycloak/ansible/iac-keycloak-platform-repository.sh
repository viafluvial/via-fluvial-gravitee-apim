#!/bin/bash

ACTION=$1
CONTEXT=$2
CLUSTER=$3

set -o errexit
set -o nounset
set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ANSIBLE_CONFIG_PATH="$SCRIPT_DIR/config/ansible.cfg"

INVENTORY_GROUP=""
PORTAINER_ENV_FILE=""

ALLOW_UNINSTALL="${ALLOW_UNINSTALL:-false}"
FORCE_UNINSTALL="${FORCE_UNINSTALL:-false}"

resolve_inventory_group() {
    case "$CLUSTER" in
        repository)
            INVENTORY_GROUP="repository"
            ;;
        *)
            echo "Erro: CLUSTER inválido '$CLUSTER'. Use: repository."
            exit 1
            ;;
    esac
}

resolve_portainer_env_file() {
    PORTAINER_ENV_FILE="./config/portainer-repository.env"
}

load_portainer_env() {
    if [[ ! -f "$PORTAINER_ENV_FILE" ]]; then
        echo "Erro: arquivo de configuração do Portainer não encontrado: $PORTAINER_ENV_FILE"
        exit 1
    fi

    set -a
    # shellcheck disable=SC1090
    . "$PORTAINER_ENV_FILE"
    set +a

    if [[ -z "${PORTAINER_URL:-}" || ( -z "${PORTAINER_ENDPOINT_ID:-}" && -z "${PORTAINER_ENDPOINT_NAME:-}" ) ]]; then
        echo "Erro: PORTAINER_URL e PORTAINER_ENDPOINT_ID (ou PORTAINER_ENDPOINT_NAME) devem ser definidos em $PORTAINER_ENV_FILE"
        exit 1
    fi

    if [[ -z "${PORTAINER_API_KEY:-}" && ( -z "${PORTAINER_USERNAME:-}" || -z "${PORTAINER_PASSWORD:-}" ) ]]; then
        echo "Erro: defina PORTAINER_API_KEY ou PORTAINER_USERNAME/PORTAINER_PASSWORD em $PORTAINER_ENV_FILE"
        exit 1
    fi
}

run_playbook() {
    local playbook_path=$1
    local description=$2

    # Best-effort: se o inventário estiver com ansible_user "suspeito" (parece senha)
    # e SSH_USER não estiver definido, tentar o usuário local como fallback.
    if [[ -z "${SSH_USER:-}" ]]; then
        inv_user=$(awk -v grp="$INVENTORY_GROUP" '
            $0 ~ "^\\[" grp "\\]" {in_grp=1; next}
            in_grp && /^\[/ {exit}
            in_grp && $0 !~ /^[[:space:]]*#/ && $0 ~ /ansible_user=/ {
                for (i=1; i<=NF; i++) {
                    if ($i ~ /^ansible_user=/) {
                        sub(/^ansible_user=/, "", $i)
                        print $i
                        exit
                    }
                }
            }
        ' ./config/inventory.ini 2>/dev/null || true)

        if [[ -n "${inv_user:-}" ]]; then
            if [[ ${#inv_user} -ge 10 && "$inv_user" =~ [A-Z] && "$inv_user" =~ [a-z] && "$inv_user" =~ [0-9] ]]; then
                echo "[SSH] Aviso: ansible_user do inventário ('${inv_user}') parece uma senha; tentando fallback com usuário local '$USER'." >&2
                SSH_USER="$USER"
            fi
        fi
    fi

    local ansible_ssh_opts=()
    if [[ -n "${SSH_USER:-}" ]]; then
        ansible_ssh_opts+=("-u" "$SSH_USER")
    fi
    if [[ -n "${SSH_PRIVATE_KEY_FILE:-}" ]]; then
        ansible_ssh_opts+=("--private-key" "$SSH_PRIVATE_KEY_FILE")
    fi
    if [[ -n "${SSH_COMMON_ARGS:-}" ]]; then
        ansible_ssh_opts+=("--ssh-common-args" "$SSH_COMMON_ARGS")
    fi
    if [[ -n "${SSH_PASSWORD:-}" ]]; then
        ansible_ssh_opts+=("-e" "ansible_password=${SSH_PASSWORD}")
    fi
    if [[ -n "${SUDO_PASSWORD:-}" ]]; then
        ansible_ssh_opts+=("-e" "ansible_become_password=${SUDO_PASSWORD}")
    fi

    if [[ "$CONTEXT" != "local" ]]; then
        echo "[SSH] Precheck: ansible ping no grupo '$INVENTORY_GROUP'"
        set +e
        ANSIBLE_CONFIG="$ANSIBLE_CONFIG_PATH" ansible -i ./config/inventory.ini "$INVENTORY_GROUP" "${ansible_ssh_opts[@]}" -m ping >/dev/null 2>&1
        ping_rc=$?
        set -e
        if [[ $ping_rc -ne 0 ]]; then
            echo "[SSH] Falha ao conectar via SSH (ansible ping)." >&2
            echo "[SSH] Dicas rápidas:" >&2
            echo "[SSH] - Verifique se ansible_user no inventário é o USUÁRIO SSH (não a senha)." >&2
            echo "[SSH] - Se você usa chave: exporte SSH_USER e SSH_PRIVATE_KEY_FILE." >&2
            echo "[SSH]   Ex: SSH_USER=seu_usuario SSH_PRIVATE_KEY_FILE=~/.ssh/id_ed25519 make install-postgresql" >&2
            echo "[SSH] - Se você usa senha (sshpass): exporte SSH_USER e SSH_PASSWORD." >&2
            echo "[SSH]   Ex: SSH_USER=seu_usuario SSH_PASSWORD='sua_senha' make install-postgresql" >&2
            exit 4
        fi
    fi

    echo "Iniciando ${description}..."
    if [[ "$CONTEXT" == "local" ]]; then
        ANSIBLE_CONFIG="$ANSIBLE_CONFIG_PATH" ansible-playbook \
            -i "localhost," \
            -c local \
            "$playbook_path" \
            -e force_uninstall="$FORCE_UNINSTALL"
    else
        ANSIBLE_CONFIG="$ANSIBLE_CONFIG_PATH" ansible-playbook \
            -i ./config/inventory.ini \
            "${ansible_ssh_opts[@]}" \
            "$playbook_path" \
            --limit "$INVENTORY_GROUP" \
            -e force_uninstall="$FORCE_UNINSTALL"
    fi

    echo "${description} concluído com sucesso."
}

verify_parameters() {
    if [[ -z "${ACTION:-}" ]]; then
        echo "Erro: O parâmetro 'ACTION' não foi fornecido."
        exit 1
    elif [[ -z "${CLUSTER:-}" ]]; then
        echo "Erro: O parâmetro 'CLUSTER' não foi fornecido."
        exit 1
    elif [[ -z "${CONTEXT:-}" ]]; then
        echo "Erro: O parâmetro 'CONTEXT' não foi fornecido."
        exit 1
    fi

    if [[ "$ACTION" != "install" && "$ACTION" != "uninstall" && "$ACTION" != "validate" ]]; then
        echo "Erro: ACTION inválido '$ACTION'. Use 'install', 'validate' ou 'uninstall'."
        exit 1
    fi

    if [[ "$CONTEXT" != "local" && "$CONTEXT" != "remote" ]]; then
        echo "Erro: CONTEXT inválido '$CONTEXT'. Use 'local' ou 'remote'."
        exit 1
    fi
}

confirm_procedure() {
    echo -e "\n** ATENÇÃO **"
    echo "Você está prestes a realizar a operação '$ACTION' no cluster '$CLUSTER'."
    if [[ "$ACTION" == "uninstall" ]]; then
        echo "ESTA AÇÃO IRÁ REMOVER O POSTGRESQL DO KEYCLOAK."
    fi

    read -r -p "Você tem certeza que deseja continuar? [s/N]: " confirm
    if [[ "$confirm" != "s" && "$confirm" != "S" ]]; then
        echo "Operação cancelada pelo usuário."
        exit 0
    fi

    if [[ "$ACTION" == "uninstall" ]]; then
        read -r -p "Você confirmou backups do banco e janela? [s/N]: " backup
        if [[ "$backup" != "s" && "$backup" != "S" ]]; then
            echo "Por favor, confirme backups/janela antes de continuar."
            exit 0
        fi
    fi
}

install_postgresql() {
    run_playbook ./playbooks/keycloak/playbook-00C-install-keycloak-postgresql-repository.yml "instalação/atualização do PostgreSQL do Keycloak"
}

validate_postgresql() {
    run_playbook ./playbooks/keycloak/playbook-00V-validate-keycloak-postgresql-repository.yml "validação do PostgreSQL do Keycloak"
}

uninstall_postgresql() {
    if [[ "$ALLOW_UNINSTALL" != "true" ]]; then
        echo "Operação bloqueada: uninstall está desabilitado por política de segurança."
        exit 1
    fi
    confirm_procedure
    run_playbook ./playbooks/keycloak/playbook-00D-uninstall-keycloak-postgresql-repository.yml "remoção do PostgreSQL do Keycloak"
}

main() {
    echo "Total parameters:"
    echo "Action: $ACTION"
    echo "Context: $CONTEXT"
    echo "Cluster: $CLUSTER"

    verify_parameters
    resolve_inventory_group
    resolve_portainer_env_file
    load_portainer_env

    if [[ "$CONTEXT" == "local" ]]; then
        echo "Inventory group selecionado: localhost (local)"
    else
        echo "Inventory group selecionado: $INVENTORY_GROUP"
    fi
    echo "Configuração Portainer carregada de: $PORTAINER_ENV_FILE"

    case "$ACTION" in
        install)
            install_postgresql
            ;;
        validate)
            validate_postgresql
            ;;
        uninstall)
            uninstall_postgresql
            ;;
    esac
}

main
