# Keycloak on-prem (Docker Swarm + Portainer API)

Implantação institucional do **Keycloak** em cluster **Docker Swarm** já existente, com **Traefik** e **Portainer** já operacionais.

## Visão arquitetural

- **Cluster identity** (`10.47.95.116`): hospeda **Keycloak**, integrado ao Traefik existente via labels.
- **Cluster repository** (`10.47.76.182`): hospeda o **PostgreSQL** do Keycloak.
- DNS:
  - Público: `sso-identity.tjam.jus.br`
  - Administrativo (interno/VPN): `admin-sso-identity.tjam.jus.br`
  - Banco (interno entre clusters): `keycloak-postgresql-repository.tjam.jus.br`

Stacks (nomes no Swarm/Portainer):

- `keycloak_identity`
- `keycloak_postgresql`

## Estrutura

- `Makefile`: comandos de alto nível (install/validate/uninstall/checks).
- `scripts/`: bootstrap local e validação Portainer API.
- `applications/keycloak/identity/`: stack Swarm (compose) do Keycloak.
- `applications/keycloak/repository/`: stack Swarm (compose) do PostgreSQL do Keycloak.
- `ansible/config/`: inventário e env do Portainer.
- `ansible/playbooks/keycloak/`: playbooks install/validate/uninstall + tasks reutilizáveis.
- `ansible/iac-keycloak-platform-identity.sh`: orquestração do Keycloak.
- `ansible/iac-keycloak-platform-repository.sh`: orquestração do PostgreSQL.

## Sizing inicial (10 mil usuários/dia)

Premissas típicas para ambiente institucional:

- 10k usuários/dia normalmente não significa 10k concorrentes; picos reais costumam ficar na faixa de **dezenas a poucas centenas de sessões ativas** e **rajadas** de autenticação em horário comercial.
- O custo dominante em login é I/O no banco + criptografia + geração de tokens.

Proposta inicial prudente:

- **Keycloak**: `2` réplicas (alta disponibilidade), com sticky session no Traefik.
- **CPU/memória por réplica**:
  - `reservation`: 0.5 CPU / 1.5Gi
  - `limit`: 1.0 CPU / 2.0Gi
- **Heap JVM**: alvo de ~1.2–1.4Gi, mantendo folga para metaspace/threads (configurado via `JAVA_OPTS_APPEND` no `.env.keycloak`).
- **Pool de conexão** (Keycloak → Postgres): começar com `KC_DB_POOL_INITIAL_SIZE=5` e `KC_DB_POOL_MAX_SIZE=30` por réplica.

Racional: 2 réplicas absorvem manutenção/queda de nó sem indisponibilidade total; recursos por réplica são suficientes para picos moderados mantendo GC estável; pool total máximo (2×30=60) é viável para Postgres bem dimensionado.

## Requisitos locais

- `bash`, `curl`, `python3`
- `ansible-playbook`
- `sshpass` (caso use senha no inventário)

## SSH (importante)

O erro `Permission denied (publickey,password)` normalmente indica `ansible_user` incorreto no inventário ou ausência de credencial (chave/senha).

- `ansible_user` deve ser o **usuário SSH real** do host (não a senha).
- Alternativas rápidas sem editar o inventário (overrides por ambiente):

```bash
# via chave
SSH_USER=seu_usuario SSH_PRIVATE_KEY_FILE=~/.ssh/id_ed25519 ENVIRONMENT=prd make stacks install platform

# via senha (requer sshpass instalado)
SSH_USER=seu_usuario SSH_PASSWORD='sua_senha' ENVIRONMENT=prd make stacks install platform

# se o sudo pedir senha diferente
SSH_USER=seu_usuario SSH_PASSWORD='senha_ssh' SUDO_PASSWORD='senha_sudo' ENVIRONMENT=prd make stacks install platform
```

Opcional: você pode passar parâmetros extras de SSH (ex.: desabilitar prompt de host key) usando `SSH_COMMON_ARGS`, por exemplo:

```bash
SSH_COMMON_ARGS='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null' \
  SSH_USER=seu_usuario SSH_PRIVATE_KEY_FILE=~/.ssh/id_ed25519 \
  ENVIRONMENT=prd make stacks install platform
```

Bootstrap local (opcional):

```bash
make setup-local
```

## Configuração

1) Ajuste o inventário:

- copie o exemplo e edite o arquivo real (não versionado):
  - `cp ansible/config/inventory.ini.example ansible/config/inventory.ini`

Observação importante sobre grupos do inventário:

- O projeto usa diretamente os grupos `identity` (Keycloak) e `repository` (PostgreSQL).
- Você pode manter grupos adicionais (ex.: `dsv`, `hml`) para seu controle, mas os alvos dos comandos padrão são `identity` e `repository`.

Opcional (somente se você quiser customizar variáveis via `-e`/Vault):

- `ansible/config/credentials.yml.example`

2) Ajuste Portainer:

- copie os exemplos e edite os arquivos reais (não versionados):
  - `cp ansible/config/portainer-identity.env.example ansible/config/portainer-identity.env`
  - `cp ansible/config/portainer-repository.env.example ansible/config/portainer-repository.env`

Nota sobre `PORTAINER_ENDPOINT_ID`:

- Nem todo Portainer usa `endpointId=1`. Se você receber 404 em `/api/endpoints/<id>`, ajuste `PORTAINER_ENDPOINT_ID` ou defina `PORTAINER_ENDPOINT_NAME` (Name exato retornado por `GET /api/endpoints`).

3) Ajuste variáveis do Keycloak:

- copie os exemplos e edite os arquivos reais (não versionados):
  - `cp ansible/playbooks/keycloak/.env.keycloak.example ansible/playbooks/keycloak/.env.keycloak`
  - `cp ansible/playbooks/keycloak/.env.keycloak-postgresql.example ansible/playbooks/keycloak/.env.keycloak-postgresql`

Nota sobre imagem do Keycloak:

- Por padrão o compose usa `quay.io/keycloak/keycloak` (imagem oficial).
- Se você quiser usar Docker Hub, defina `KEYCLOAK_IMAGE=keycloak/keycloak` no `.env.keycloak`.

Nota sobre segurança:

- Não versione `inventory.ini`, `portainer-*.env` e os `.env` de stacks (contêm dados sensíveis).
- O compose do PostgreSQL publica `5432` em modo `host`: restrinja o acesso a nível de rede/firewall.

## Deploy

Deploy (ponta a ponta):

```bash
make check-tools
make check-portainer-connectivity
make install-platform
```

Deploy no estilo "stacks" (aderente ao projeto base do cluster):

```bash
# identity | repository | platform
ENVIRONMENT=prd make stacks install platform

# valida sintaxe dos playbooks (não faz deploy)
ENVIRONMENT=prd make stacks check platform
```

Deploy por componente:

```bash
make install-postgresql
make validate-postgresql

make install-keycloak
make validate-keycloak
```

## Validação

```bash
make validate-platform
```

Checks rápidos via Portainer API:

```bash
make check-portainer-connectivity
make check-repository-stacks
make check-identity-stacks
```

Nota sobre ENVIRONMENT:

- `ENVIRONMENT=prd`:
  - `TARGET=identity` roda no grupo `identity`
  - `TARGET=repository` roda no grupo `repository`
  - `TARGET=platform` executa o fluxo PostgreSQL -> Keycloak
- `ENVIRONMENT=dsv|hml`: por padrão usa o grupo do próprio ambiente.

## Desinstalação (protegida)

```bash
make uninstall-platform ALLOW_UNINSTALL=true
```

Remoção por componente:

```bash
make uninstall-keycloak ALLOW_UNINSTALL=true
make uninstall-postgresql ALLOW_UNINSTALL=true
```

Modo stacks (destrutivo):

```bash
ALLOW_UNINSTALL=true ENVIRONMENT=prd make stacks uninstall platform
```

`clean` e `clean-hard`:

- `clean`: ajusta `task-history-limit` e força rollout (`docker service update --force`) nas stacks alvo.
- `clean-hard`: faz `uninstall -> install` e exige `ALLOW_UNINSTALL=true`.

Para forçar limpeza do diretório remoto (quando suportado pelo playbook):

```bash
make uninstall-keycloak ALLOW_UNINSTALL=true FORCE=true
```

## Operação rápida

No manager do Swarm (cluster identity):

```bash
docker stack ps keycloak_identity
docker service ls | grep keycloak_identity
docker service logs --tail 200 -f keycloak_identity_keycloak
```

No manager do Swarm (cluster repository):

```bash
docker stack ps keycloak_postgresql
docker service ls | grep keycloak_postgresql
docker service logs --tail 200 -f keycloak_postgresql_postgresql
```
