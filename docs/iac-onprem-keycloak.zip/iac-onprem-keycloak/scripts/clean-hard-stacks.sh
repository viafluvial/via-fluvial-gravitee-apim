#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Uso: $0 <identity|repository|platform>" >&2
  exit 1
fi

TARGET="$1"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENVIRONMENT="${ENVIRONMENT:-prd}"
WITH_PREREQS="${WITH_PREREQS:-false}"

bash "$ROOT_DIR/scripts/iac.sh" clean-hard "$ENVIRONMENT" "$TARGET" "$WITH_PREREQS"

echo "Clean-hard concluído para ${TARGET} em ${ENVIRONMENT}."
