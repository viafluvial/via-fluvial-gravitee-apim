#!/usr/bin/env bash
set -euo pipefail

ACTION="${1:-install}"
ENVIRONMENT="${2:-prd}"
TARGET="${3:-identity}"
WITH_PREREQS="${4:-false}"

INVENTORY_LIMIT="${INVENTORY_LIMIT:-}"
INVENTORY_FILE_OVERRIDE="${INVENTORY_FILE_OVERRIDE:-}"
ALLOW_DSV_CHANGES="${ALLOW_DSV_CHANGES:-false}"
TASK_HISTORY_LIMIT="${TASK_HISTORY_LIMIT:-1}"
CLEAN_STACKS="${CLEAN_STACKS:-}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ANSIBLE_DIR="$ROOT_DIR/ansible"
PLAYBOOKS_DIR="$ANSIBLE_DIR/playbooks/keycloak"
INVENTORY_FILE="$ANSIBLE_DIR/config/inventory.ini"

INVENTORY_GROUP=""
EFFECTIVE_CLUSTER=""

usage() {
	cat <<USAGE
Uso:
	scripts/iac.sh <install|uninstall|check|clean|clean-hard> [dsv|hml|prd] [identity|repository|platform] [true|false]

Exemplos:
	ENVIRONMENT=prd scripts/iac.sh install prd platform
	ENVIRONMENT=prd scripts/iac.sh check prd identity
	TASK_HISTORY_LIMIT=1 scripts/iac.sh clean prd platform
	ALLOW_UNINSTALL=true scripts/iac.sh clean-hard prd platform

Variaveis opcionais (estilo projeto de referência):
	INVENTORY_LIMIT=<grupo_ou_host>          (sobrescreve --limit)
	INVENTORY_FILE_OVERRIDE=<arquivo.ini>    (sobrescreve inventario)
	ALLOW_DSV_CHANGES=true                  (libera alteracoes em dsv)
	TASK_HISTORY_LIMIT=<n>                  (default: 1)
	CLEAN_STACKS=<csv>                      (sobrescreve stacks para clean, ex: keycloak_identity,keycloak_postgresql)
USAGE
}

require_tools() {
	command -v ansible-playbook >/dev/null 2>&1 || {
		echo "ansible-playbook nao encontrado. Execute: make setup-local" >&2
		exit 1
	}
}

resolve_target() {
	case "$ENVIRONMENT" in
		dsv)
			INVENTORY_GROUP="dsv"
			EFFECTIVE_CLUSTER="dsv"
			;;
		hml)
			INVENTORY_GROUP="hml"
			EFFECTIVE_CLUSTER="hml"
			;;
		prd)
			# prd: Keycloak no grupo identity e Postgres no grupo repository
			case "$TARGET" in
				identity)
					INVENTORY_GROUP="identity"
					EFFECTIVE_CLUSTER="identity"
					;;
				repository)
					INVENTORY_GROUP="repository"
					EFFECTIVE_CLUSTER="repository"
					;;
				platform)
					# group depende do passo; mantemos aqui como identity (default)
					INVENTORY_GROUP="identity"
					EFFECTIVE_CLUSTER="identity"
					;;
				*)
					echo "TARGET '$TARGET' nao suportado. Use identity, repository ou platform." >&2
					exit 1
					;;
			esac
			;;
		*)
			echo "Ambiente '$ENVIRONMENT' nao suportado. Use dsv, hml ou prd." >&2
			exit 1
			;;
	esac

	if [[ -n "$INVENTORY_FILE_OVERRIDE" ]]; then
		INVENTORY_FILE="$INVENTORY_FILE_OVERRIDE"
	fi

	if [[ ! -f "$INVENTORY_FILE" ]]; then
		echo "Arquivo de inventario nao encontrado: $INVENTORY_FILE" >&2
		exit 1
	fi

	if [[ -n "$INVENTORY_LIMIT" ]]; then
		INVENTORY_GROUP="$INVENTORY_LIMIT"
	fi

	echo "[iac] Ambiente: $ENVIRONMENT"
	echo "[iac] Target: $TARGET"
	echo "[iac] Inventory file: $INVENTORY_FILE"
	echo "[iac] Limit/Grupo: $INVENTORY_GROUP"
}

guard_environment_safety() {
	if [[ "$ENVIRONMENT" == "dsv" && ( "$ACTION" == "install" || "$ACTION" == "uninstall" || "$ACTION" == "clean" || "$ACTION" == "clean-hard" ) && "$ALLOW_DSV_CHANGES" != "true" ]]; then
		echo "[iac] Bloqueado por seguranca: alteracoes em dsv exigem ALLOW_DSV_CHANGES=true." >&2
		echo "[iac] Exemplo: ALLOW_DSV_CHANGES=true ENVIRONMENT=dsv make stacks $ACTION <target>" >&2
		exit 1
	fi
}

run_playbook_syntax_check() {
	local pb
	for pb in "$PLAYBOOKS_DIR"/playbook-*.yml; do
		ANSIBLE_CONFIG="$ANSIBLE_DIR/config/ansible.cfg" ansible-playbook \
			--syntax-check \
			-i "$INVENTORY_FILE" \
			"$pb" \
			--limit "$INVENTORY_GROUP" >/dev/null
	done
	echo "[iac] ansible-playbook --syntax-check: OK"
}

run_install() {
	case "$TARGET" in
		identity)
			( cd "$ROOT_DIR" && make install-keycloak CONTEXT=remote )
			;;
		repository)
			( cd "$ROOT_DIR" && make install-postgresql CONTEXT=remote )
			;;
		platform)
			( cd "$ROOT_DIR" && make install-platform CONTEXT=remote )
			;;
		*)
			echo "TARGET '$TARGET' nao suportado. Use identity, repository ou platform." >&2
			exit 1
			;;
	esac
}

run_uninstall() {
	case "$TARGET" in
		identity)
			( cd "$ROOT_DIR" && make uninstall-keycloak CONTEXT=remote ALLOW_UNINSTALL="${ALLOW_UNINSTALL:-false}" FORCE="${FORCE:-false}" )
			;;
		repository)
			( cd "$ROOT_DIR" && make uninstall-postgresql CONTEXT=remote ALLOW_UNINSTALL="${ALLOW_UNINSTALL:-false}" FORCE="${FORCE:-false}" )
			;;
		platform)
			( cd "$ROOT_DIR" && make uninstall-platform CONTEXT=remote ALLOW_UNINSTALL="${ALLOW_UNINSTALL:-false}" FORCE="${FORCE:-false}" )
			;;
		*)
			echo "TARGET '$TARGET' nao suportado. Use identity, repository ou platform." >&2
			exit 1
			;;
	esac
}

resolve_clean_stacks_csv() {
	if [[ -n "$CLEAN_STACKS" ]]; then
		echo "$CLEAN_STACKS"
		return
	fi

	case "$TARGET" in
		identity)
			echo "keycloak_identity"
			;;
		repository)
			echo "keycloak_postgresql"
			;;
		platform)
			echo "keycloak_identity,keycloak_postgresql"
			;;
		*)
			echo "keycloak_identity,keycloak_postgresql"
			;;
	esac
}

run_clean() {
	if ! [[ "$TASK_HISTORY_LIMIT" =~ ^[0-9]+$ ]]; then
		echo "TASK_HISTORY_LIMIT deve ser numerico. Valor atual: $TASK_HISTORY_LIMIT" >&2
		exit 1
	fi

	local stacks_csv
	stacks_csv="$(resolve_clean_stacks_csv)"

	ANSIBLE_CONFIG="$ANSIBLE_DIR/config/ansible.cfg" ansible-playbook \
		-i "$INVENTORY_FILE" \
		"$PLAYBOOKS_DIR/playbook-90C-clean-services.yml" \
		--limit "$INVENTORY_GROUP" \
		-e "task_history_limit=$TASK_HISTORY_LIMIT" \
		-e "clean_stacks_csv=$stacks_csv"
}

run_clean_hard() {
	# clean-hard = uninstall + install (destrutivo). Requer ALLOW_UNINSTALL=true.
	if [[ "${ALLOW_UNINSTALL:-false}" != "true" ]]; then
		echo "[iac] clean-hard requer ALLOW_UNINSTALL=true" >&2
		exit 1
	fi

	echo "[iac] Executando clean-hard: uninstall -> install"
	"$ROOT_DIR/scripts/iac.sh" uninstall "$ENVIRONMENT" "$TARGET" "$WITH_PREREQS"
	"$ROOT_DIR/scripts/iac.sh" install "$ENVIRONMENT" "$TARGET" "$WITH_PREREQS"
}

if [[ "$WITH_PREREQS" == "true" ]]; then
	bash "$ROOT_DIR/scripts/bootstrap-local.sh"
fi

if [[ "$ACTION" == "-h" || "$ACTION" == "--help" ]]; then
	usage
	exit 0
fi

require_tools
resolve_target
guard_environment_safety

case "$ACTION" in
	install)
		run_install
		;;
	uninstall)
		run_uninstall
		;;
	check)
		run_playbook_syntax_check
		;;
	clean)
		run_clean
		;;
	clean-hard)
		run_clean_hard
		;;
	*)
		echo "Acao '$ACTION' nao suportada." >&2
		usage >&2
		exit 1
		;;
esac
