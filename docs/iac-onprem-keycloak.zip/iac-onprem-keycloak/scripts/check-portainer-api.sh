#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Uso: $0 <env-file> [stack_name ...]" >&2
  exit 1
fi

env_file="$1"
shift || true
stacks=("$@")

if [[ ! -f "$env_file" ]]; then
  echo "Arquivo env não encontrado: $env_file" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
. "$env_file"
set +a

: "${PORTAINER_URL:?PORTAINER_URL não definido em $env_file}"
portainer_endpoint_id_raw="${PORTAINER_ENDPOINT_ID:-}"
portainer_endpoint_name_raw="${PORTAINER_ENDPOINT_NAME:-}"

if [[ "$portainer_endpoint_id_raw" == "CHANGE_ME" ]]; then
  echo "PORTAINER_ENDPOINT_ID está como CHANGE_ME em $env_file. Ajuste para o Id real do endpoint ou use PORTAINER_ENDPOINT_NAME." >&2
  exit 1
fi

if [[ -z "$portainer_endpoint_id_raw" && -z "$portainer_endpoint_name_raw" ]]; then
  echo "Defina PORTAINER_ENDPOINT_ID ou PORTAINER_ENDPOINT_NAME em $env_file" >&2
  exit 1
fi

if [[ -z "${PORTAINER_API_KEY:-}" && ( -z "${PORTAINER_USERNAME:-}" || -z "${PORTAINER_PASSWORD:-}" ) ]]; then
  echo "Defina PORTAINER_API_KEY ou PORTAINER_USERNAME/PORTAINER_PASSWORD em $env_file" >&2
  exit 1
fi

base_url="${PORTAINER_URL%/}"
validate_certs="${PORTAINER_VALIDATE_CERTS:-false}"
api_timeout="${PORTAINER_API_TIMEOUT:-120}"
service_health_timeout="${PORTAINER_SERVICE_HEALTH_TIMEOUT:-600}"
service_health_interval="${PORTAINER_SERVICE_HEALTH_INTERVAL:-10}"

portainer_host=$(python3 - <<'PY' "$base_url"
import sys
from urllib.parse import urlparse

url = sys.argv[1].strip()
parsed = urlparse(url)
print(parsed.hostname or '')
PY
)

if [[ -z "$portainer_host" ]]; then
  echo "URL do Portainer inválida em $env_file: $PORTAINER_URL" >&2
  exit 1
fi

if ! getent hosts "$portainer_host" >/dev/null 2>&1; then
  echo "[Portainer] Falha de DNS para host '$portainer_host'." >&2
  echo "[Portainer] Valide VPN/rede corporativa e resolução DNS antes do deploy." >&2
  echo "[Portainer] Dica: teste com 'getent hosts $portainer_host'." >&2
  exit 1
fi

curl_opts=(--silent --show-error --fail --max-time "$api_timeout")
if [[ "$validate_certs" == "false" ]]; then
  curl_opts+=(--insecure)
fi

api_headers=()

echo "[Portainer] Verificando conectividade: $base_url"
curl "${curl_opts[@]}" "$base_url/api/status" >/dev/null

if [[ -n "${PORTAINER_API_KEY:-}" ]]; then
  api_headers=(-H "X-API-Key: ${PORTAINER_API_KEY}")
else
  echo "[Portainer] Autenticando com usuário/senha"
  auth_response=$(curl "${curl_opts[@]}" \
    -H "Content-Type: application/json" \
    -X POST \
    -d "{\"username\":\"${PORTAINER_USERNAME}\",\"password\":\"${PORTAINER_PASSWORD}\"}" \
    "$base_url/api/auth")

  jwt=$(python3 - <<'PY' "$auth_response"
import json,sys
try:
    data=json.loads(sys.argv[1])
    print(data.get('jwt',''))
except Exception:
    print('')
PY
)

  if [[ -z "$jwt" ]]; then
    echo "Falha ao autenticar no Portainer (jwt vazio)." >&2
    exit 1
  fi

  api_headers=(-H "Authorization: Bearer $jwt")
fi

endpoints_response=$(curl "${curl_opts[@]}" "${api_headers[@]}" "$base_url/api/endpoints")

resolve_endpoint_id() {
  python3 - <<'PY' "$endpoints_response" "$portainer_endpoint_id_raw" "$portainer_endpoint_name_raw"
import json,sys

raw=sys.argv[1]
endpoint_id=(sys.argv[2] or '').strip()
endpoint_name=(sys.argv[3] or '').strip()

try:
  endpoints=json.loads(raw)
except Exception:
  endpoints=None

if not isinstance(endpoints, list):
  print('')
  sys.exit(0)

def norm(s: str) -> str:
  return (s or '').strip().lower()

endpoints_by_id={str((e or {}).get('Id')): (e or {}) for e in endpoints if isinstance(e, dict)}

if endpoint_id and endpoint_id in endpoints_by_id:
  print(endpoint_id)
  sys.exit(0)

if endpoint_name:
  want=norm(endpoint_name)
  matches=[e for e in endpoints if isinstance(e, dict) and norm(e.get('Name',''))==want]
  if len(matches)==1:
    print(str(matches[0].get('Id','')))
    sys.exit(0)

if len(endpoints)==1 and isinstance(endpoints[0], dict):
  print(str(endpoints[0].get('Id','')))
  sys.exit(0)

print('')
PY
}

resolved_endpoint_id="$(resolve_endpoint_id)"

if [[ -z "$resolved_endpoint_id" ]]; then
  echo "[Portainer] Endpoint não resolvido." >&2
  echo "[Portainer] PORTAINER_ENDPOINT_ID informado: '${portainer_endpoint_id_raw:-<vazio>}'" >&2
  echo "[Portainer] PORTAINER_ENDPOINT_NAME informado: '${portainer_endpoint_name_raw:-<vazio>}'" >&2
  echo "[Portainer] Endpoints disponíveis (Id: Name):" >&2
  python3 - <<'PY' "$endpoints_response" >&2
import json,sys
try:
  endpoints=json.loads(sys.argv[1])
except Exception as exc:
  print(f'  (falha ao parsear /api/endpoints: {exc})')
  sys.exit(0)

if not isinstance(endpoints, list):
  print('  (resposta inesperada de /api/endpoints)')
  sys.exit(0)

for e in endpoints:
  if not isinstance(e, dict):
    continue
  _id=e.get('Id')
  name=e.get('Name')
  if _id is None and name is None:
    continue
  print(f"  - {_id}: {name}")
PY
  echo "[Portainer] Ajuste PORTAINER_ENDPOINT_ID ou defina PORTAINER_ENDPOINT_NAME para um Name acima." >&2
  exit 1
fi

echo "[Portainer] Usando endpointId=$resolved_endpoint_id"
curl "${curl_opts[@]}" "${api_headers[@]}" "$base_url/api/endpoints/$resolved_endpoint_id" >/dev/null

stacks_response=$(curl "${curl_opts[@]}" "${api_headers[@]}" "$base_url/api/stacks?endpointId=$resolved_endpoint_id")

if [[ ${#stacks[@]} -gt 0 ]]; then
  echo "[Portainer] Validando stacks no endpoint $resolved_endpoint_id"
  python3 - <<'PY' "$stacks_response" "${stacks[@]}"
import json,sys
raw=sys.argv[1]
expected=set(sys.argv[2:])
try:
    data=json.loads(raw)
except Exception as exc:
    print(f'Falha ao parsear resposta de stacks: {exc}', file=sys.stderr)
    sys.exit(1)
found={item.get('Name') for item in data if isinstance(item, dict)}
missing=sorted(expected - found)
if missing:
    print('Stacks ausentes: ' + ', '.join(missing), file=sys.stderr)
    sys.exit(1)
print('Stacks validadas: ' + ', '.join(sorted(expected)))
PY

  echo "[Portainer] Validando saúde dos serviços (replicas running)"
  echo "[Portainer] Aguardando até ${service_health_timeout}s (intervalo ${service_health_interval}s) para estabilização"

  last_validation_output=""
  elapsed=0
  while true; do
    services_response=$(curl "${curl_opts[@]}" "${api_headers[@]}" "$base_url/api/endpoints/$resolved_endpoint_id/docker/services?status=true")

    set +e
    validation_output=$(python3 - <<'PY' "$services_response" "${stacks[@]}"
import json,sys

raw=sys.argv[1]
expected_stacks=set(sys.argv[2:])

try:
  services=json.loads(raw)
except Exception as exc:
  print(f'Falha ao parsear resposta de serviços: {exc}', file=sys.stderr)
  sys.exit(1)

if not isinstance(services, list):
  print('Resposta de serviços inválida (esperada lista).', file=sys.stderr)
  sys.exit(1)

stack_services={stack: [] for stack in expected_stacks}

for svc in services:
  if not isinstance(svc, dict):
    continue
  labels=((svc.get('Spec') or {}).get('Labels') or {})
  stack_name=labels.get('com.docker.stack.namespace')
  if stack_name in stack_services:
    stack_services[stack_name].append(svc)

errors=[]
details=[]

for stack_name in sorted(expected_stacks):
  svcs=stack_services.get(stack_name, [])
  if not svcs:
    errors.append(f'Nenhum serviço encontrado para a stack {stack_name}')
    continue

  for svc in svcs:
    spec=svc.get('Spec') or {}
    mode=spec.get('Mode') or {}
    if 'Replicated' in mode:
      desired=int((mode.get('Replicated') or {}).get('Replicas') or 0)
    elif 'Global' in mode:
      desired=1
    else:
      desired=1

    status=svc.get('ServiceStatus') or {}
    running=int(status.get('RunningTasks') or 0)
    name=spec.get('Name') or svc.get('ID') or 'unknown'

    details.append(f'{name}: {running}/{desired}')

    if desired > 0 and running < desired:
      errors.append(f'Serviço {name} não saudável: {running}/{desired} tasks running')

if errors:
  print('Falha na validação de saúde das stacks:')
  for err in errors:
    print(f' - {err}')
  if details:
    print('Resumo:')
    for item in details:
      print(f'   * {item}')
  sys.exit(1)

print('Serviços saudáveis:')
for item in details:
  print(f' - {item}')
PY
)
    validation_rc=$?
    set -e

    if [[ $validation_rc -eq 0 ]]; then
      echo "$validation_output"
      break
    fi

    last_validation_output="$validation_output"
    if (( elapsed >= service_health_timeout )); then
      echo "$last_validation_output" >&2
      exit 1
    fi

    sleep "$service_health_interval"
    elapsed=$((elapsed + service_health_interval))
  done
fi

echo "[Portainer] OK: conectividade/autenticação/endpoint válidos para $env_file"
