#!/usr/bin/env bash
set -euo pipefail

echo "== Bootstrap local (make + sshpass + ansible) =="

bash ./scripts/install-make.sh
bash ./scripts/install-sshpass.sh
bash ./scripts/install-ansible.sh

echo "Bootstrap local concluído."
